const fields = {
  baseUrl: document.getElementById('baseUrl'),
  securityKey: document.getElementById('securityKey'),
  batchLimit: document.getElementById('batchLimit'),
  delayMin: document.getElementById('delayMin'),
  delayMax: document.getElementById('delayMax')
};

const autoSyncToggle = document.getElementById('autoSyncToggle');

const statusBadge = document.getElementById('statusBadge');
const messageEl = document.getElementById('message');
const queuedCount = document.getElementById('queuedCount');
const sentCount = document.getElementById('sentCount');
const failedCount = document.getElementById('failedCount');
const autoStatus = document.getElementById('autoStatus');
const lastSyncAt = document.getElementById('lastSyncAt');
const lastSyncMessage = document.getElementById('lastSyncMessage');
const lastSendError = document.getElementById('lastSendError');

document.addEventListener('DOMContentLoaded', init);
document.getElementById('saveBtn').addEventListener('click', saveSettings);
document.getElementById('validateBtn').addEventListener('click', validateSettings);
document.getElementById('pullBtn').addEventListener('click', pullCsv);
document.getElementById('startBtn').addEventListener('click', startSending);
document.getElementById('stopBtn').addEventListener('click', stopSending);
document.getElementById('clearBtn').addEventListener('click', clearQueue);
document.getElementById('csvFile').addEventListener('change', importCsvFile);
autoSyncToggle.addEventListener('change', saveSettings);

async function init() {
  const settings = await send({type: 'getSettings'});
  fields.baseUrl.value = settings.baseUrl || '';
  fields.securityKey.value = settings.securityKey || '';
  fields.batchLimit.value = settings.batchLimit || 50;
  fields.delayMin.value = settings.delayMin || 8;
  fields.delayMax.value = settings.delayMax || 15;
  autoSyncToggle.checked = settings.autoSync !== false;
  await refreshStats();
  // Keep stats live while the popup is open
  setInterval(refreshStats, 2000);
}

async function saveSettings() {
  const payload = getFormSettings();
  await send({type: 'saveSettings', settings: payload});
  showMessage('Settings saved.');
}

async function validateSettings() {
  await saveSettings();
  try {
    const result = await send({type: 'validate'});
    showMessage(result.message || 'Connection verified.');
  } catch (error) {
    showMessage(error.message || 'Unable to validate settings.');
  }
}

async function pullCsv() {
  await saveSettings();
  try {
    const result = await send({type: 'pullCsv'});
    showMessage('Imported ' + result.imported + ' row(s) from CSV feed.');
    await refreshStats();
  } catch (error) {
    showMessage(error.message || 'Unable to pull CSV.');
  }
}

async function startSending() {
  await saveSettings();
  try {
    const result = await send({type: 'start'});
    showMessage(result.message || 'Sending started.');
    await refreshStats();
  } catch (error) {
    showMessage(error.message || 'Unable to start sending.');
  }
}

async function stopSending() {
  const result = await send({type: 'stop'});
  showMessage(result.message || 'Sending stopped.');
  await refreshStats();
}

async function clearQueue() {
  await send({type: 'clearQueue'});
  showMessage('Local queue cleared.');
  await refreshStats();
}

async function importCsvFile(event) {
  const file = event.target.files[0];
  if (!file) {
    return;
  }

  const text = await file.text();
  const result = await send({type: 'importCsvText', csv: text});
  showMessage('Imported ' + result.imported + ' row(s) from file.');
  event.target.value = '';
  await refreshStats();
}

async function refreshStats() {
  const stats = await send({type: 'stats'});
  queuedCount.textContent = stats.queued || 0;
  sentCount.textContent = stats.sent || 0;
  failedCount.textContent = stats.failed || 0;
  statusBadge.textContent = stats.running ? 'Running' : 'Idle';
  statusBadge.style.background = stats.running ? '#198754' : '#607d8b';
  autoStatus.textContent = stats.autoSyncPaused ? 'Paused' : 'Ready';
  autoStatus.style.color = stats.autoSyncPaused ? '#c94a4a' : '#198754';
  lastSyncAt.textContent = formatDateTime(stats.lastSyncAt);
  lastSyncMessage.textContent = stats.lastSyncError || stats.lastSyncMessage || '';
  lastSyncMessage.className = stats.lastSyncError ? 'error-text' : 'hint';
  lastSendError.textContent = stats.lastSendError ? 'Last send error: ' + stats.lastSendError : '';
}

function getFormSettings() {
  return {
    baseUrl: fields.baseUrl.value.trim(),
    securityKey: fields.securityKey.value.trim(),
    batchLimit: Number(fields.batchLimit.value || 50),
    delayMin: Number(fields.delayMin.value || 8),
    delayMax: Number(fields.delayMax.value || 15),
    autoSync: autoSyncToggle.checked
  };
}

function showMessage(text) {
  messageEl.textContent = text;
}

function formatDateTime(value) {
  if (!value) {
    return 'Never';
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return date.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit', second: '2-digit'});
}

function send(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, response => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response || response.ok === false) {
        reject(new Error(response && response.error ? response.error : 'Extension request failed.'));
        return;
      }
      resolve(response.data || {});
    });
  });
}
