# Smart Schools WhatsApp Sender

Unpacked Chrome extension for sending Smart Schools WhatsApp campaign CSV rows through WhatsApp Web.

## Install

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click Load unpacked.
4. Select this folder: `whatsapp-chrome-extension`.

## Use

1. Log in to `https://web.whatsapp.com` in the same Chrome profile.
2. Open Smart Schools, go to Communicate > Send Whatsapp, and create a campaign.
3. Open the extension popup.
4. Enter the Smart Schools base URL and WhatsApp Web Security Key from the Send Whatsapp page.
5. Click Validate.
6. Click Save or Validate.

After settings are saved, the extension automatically checks the Smart Schools CSV feed every 20 seconds while the extension background worker is awake. When a queued or scheduled campaign becomes ready, it imports pending rows and starts sending through WhatsApp Web without pressing Pull CSV From App.
Pressing Stop pauses automatic polling; press Start, Save, or Validate to resume it.

You can also download a campaign CSV from Smart Schools and import that CSV in the extension popup.

## CSV Columns

The extension reads these headers:

```csv
item_id,campaign_id,campaign_title,recipient_name,phone_number,message_text,status,class_name,section_name
```

`item_id`, `phone_number`, and `message_text` are the important columns. If `item_id` exists, send results are reported back to Smart Schools.

## Notes

- Keep WhatsApp Web visible and logged in while sending.
- Chrome can suspend extension background workers; the extension keeps a Chrome alarm as a wake-up fallback and resumes 20-second polling when awake.
- Chrome must be open for automatic scheduled sending. If WhatsApp Web is not logged in, the item is marked failed and can be retried from Smart Schools.
- Use conservative delays to reduce failed sends and avoid triggering WhatsApp abuse controls.
- WhatsApp Web changes its DOM from time to time. If sending stops at the click step, update `content.js` selectors.
