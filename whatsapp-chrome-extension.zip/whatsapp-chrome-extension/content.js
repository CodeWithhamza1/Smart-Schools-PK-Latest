chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== 'SS_SEND_WHATSAPP') {
    return false;
  }

  sendCurrentWhatsappMessage(message.item || {})
    .then(result => sendResponse({ok: true, data: result}))
    .catch(error => sendResponse({ok: false, error: error.message || String(error)}));
  return true;
});

async function sendCurrentWhatsappMessage(item) {
  const messageText = item.message_text || item.message || '';
  const phone = normalizePhone(item.phone_number || item.phone || '');

  const composer = await waitForTargetComposer(phone, messageText, 70000);

  const invalidNumber = findText('phone number shared via url is invalid') || findText('invalid phone number');
  if (invalidNumber) {
    throw new Error('WhatsApp reports this phone number as invalid.');
  }

  const sendButton = await waitForSendButton(45000);
  if (sendButton) {
    sendButton.click();
  } else {
    if (!composer) {
      throw new Error('Send button was not found and the message composer is unavailable.');
    }
    pressEnter(composer);
  }

  // Confirm WhatsApp consumed the message (composer clears after a real send)
  const accepted = await waitForComposerClear(composer, 8000);
  if (!accepted) {
    throw new Error('WhatsApp did not accept the send command — message may not have been delivered. Will retry.');
  }

  return {message: 'Submitted WhatsApp message.'};
}

async function waitForComposerClear(composer, timeoutMs) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (!normalizeComposerText(composer.innerText)) {
      return true;
    }
    await delay(300);
  }
  return false;
}

async function waitForTargetComposer(phone, messageText, timeoutMs) {
  const expectedPhone = normalizePhone(phone);
  const expectedText = normalizeComposerText(messageText);
  if (!expectedPhone) {
    throw new Error('Missing target phone number.');
  }
  if (!expectedText) {
    throw new Error('Missing message text.');
  }

  const started = Date.now();
  let lastState = 'waiting for WhatsApp Web to open the target chat';
  while (Date.now() - started < timeoutMs) {
    if (isLoginScreen()) {
      throw new Error('WhatsApp Web is not logged in.');
    }

    const invalidNumber = findText('phone number shared via url is invalid') || findText('invalid phone number');
    if (invalidNumber) {
      throw new Error('WhatsApp reports this phone number as invalid.');
    }

    if (isOfficialWhatsappAccountScreen()) {
      throw new Error('WhatsApp opened the official WhatsApp Business account instead of the target phone number. Send was cancelled.');
    }

    clickContinueToChatButton();

    const urlPhone = getUrlPhone();
    if (urlPhone && urlPhone !== expectedPhone) {
      throw new Error('WhatsApp opened a different phone number than expected. Expected ' + expectedPhone + ', got ' + urlPhone + '.');
    }

    const composer = findComposer();
    if (composer && (!urlPhone || urlPhone === expectedPhone)) {
      if (normalizeComposerText(composer.innerText) !== expectedText) {
        fillComposer(composer, messageText);
        await delay(250);
      }

      if (normalizeComposerText(composer.innerText) === expectedText) {
        return composer;
      }

      lastState = 'message composer was found, but WhatsApp did not accept the message text';
    } else {
      lastState = urlPhone === expectedPhone
        ? 'target phone URL loaded, but message composer is not visible yet'
        : 'message composer is not visible yet';
    }

    await delay(800);
  }

  throw new Error('WhatsApp did not open the target chat with the expected message. ' + lastState + '. Send was cancelled to avoid the wrong recipient.');
}

async function waitForSendButton(timeoutMs) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const button = findSendButton();
    if (button) {
      return button;
    }
    await delay(500);
  }
  return null;
}

function findSendButton() {
  const footer = document.querySelector('footer');
  const scoped = footer ? findSendButtonIn(footer) : null;
  if (scoped) {
    return scoped;
  }

  return findSendButtonIn(document);
}

function findSendButtonIn(root) {
  const selectors = [
    'button[aria-label="Send"]',
    'button[aria-label="Send message"]',
    'div[role="button"][aria-label="Send"]',
    'div[role="button"][aria-label="Send message"]',
    'button[aria-label*="Send"]',
    'div[role="button"][aria-label*="Send"]',
    '[data-testid="send"]',
    '[data-testid*="send"]',
    '[data-icon="send"]',
    '[data-icon*="send"]'
  ];

  for (const selector of selectors) {
    const nodes = Array.prototype.slice.call(root.querySelectorAll(selector));
    for (const node of nodes) {
      const button = node.matches('button, div[role="button"]') ? node : node.closest('button, div[role="button"]');
      if (button && isVisible(button)) {
        return button;
      }
    }
  }

  const buttons = Array.prototype.slice.call(root.querySelectorAll('button, div[role="button"]'));
  return buttons.find(button => {
    const label = (button.getAttribute('aria-label') || button.getAttribute('title') || '').toLowerCase();
    return label.indexOf('send') !== -1 && isVisible(button);
  }) || null;
}

function findComposer() {
  const footer = document.querySelector('footer');
  const footerComposer = footer ? findComposerIn(footer, true) : null;
  if (footerComposer) {
    return footerComposer;
  }

  return findComposerIn(document, false);
}

function findComposerIn(root, allowGenericFooterCandidate) {
  const selectors = [
    '[contenteditable="true"][role="textbox"]',
    '[contenteditable="true"][aria-placeholder]',
    '[contenteditable="true"][aria-label]',
    '[contenteditable="true"][data-tab]',
    '[contenteditable="true"]'
  ];

  const seen = [];
  selectors.forEach(selector => {
    Array.prototype.slice.call(root.querySelectorAll(selector)).forEach(node => {
      if (seen.indexOf(node) === -1) {
        seen.push(node);
      }
    });
  });

  const candidates = seen.filter(node => isComposerCandidate(node, allowGenericFooterCandidate));
  for (let index = candidates.length - 1; index >= 0; index--) {
    return candidates[index];
  }
  return null;
}

function fillComposer(composer, messageText) {
  composer.focus();

  // Attempt 1: standard execCommand approach (most compatible with React contenteditable)
  document.execCommand('selectAll', false, null);
  document.execCommand('delete', false, null);
  document.execCommand('insertText', false, messageText);

  if (normalizeComposerText(composer.innerText) !== normalizeComposerText(messageText)) {
    // Attempt 2: manual range selection then insertText
    selectElementContents(composer);
    document.execCommand('delete', false, null);
    document.execCommand('insertText', false, messageText);
  }

  if (normalizeComposerText(composer.innerText) !== normalizeComposerText(messageText)) {
    // Attempt 3: clear innerHTML and use insertText at caret - avoids direct textContent
    // assignment which bypasses React's synthetic event reconciliation
    composer.innerHTML = '';
    placeCaretAtEnd(composer);
    document.execCommand('insertText', false, messageText);
  }

  // Always dispatch InputEvent so React/WhatsApp re-reads the composer value
  composer.dispatchEvent(new InputEvent('input', {
    bubbles: true,
    cancelable: true,
    inputType: 'insertText',
    data: messageText
  }));
}

function isComposerCandidate(element, allowGenericFooterCandidate) {
  if (!isVisible(element)) {
    return false;
  }

  const descriptor = [
    element.getAttribute('aria-label') || '',
    element.getAttribute('aria-placeholder') || '',
    element.getAttribute('placeholder') || '',
    element.getAttribute('title') || ''
  ].join(' ').toLowerCase();

  if (descriptor.indexOf('search') !== -1 || descriptor.indexOf('filter') !== -1) {
    return false;
  }

  if (descriptor.indexOf('message') !== -1 || descriptor.indexOf('type') !== -1) {
    return true;
  }

  return allowGenericFooterCandidate && !!element.closest('footer');
}

function selectElementContents(element) {
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(element);
  selection.removeAllRanges();
  selection.addRange(range);
}

function placeCaretAtEnd(element) {
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(element);
  range.collapse(false);
  selection.removeAllRanges();
  selection.addRange(range);
}

function clickContinueToChatButton() {
  const nodes = Array.prototype.slice.call(document.querySelectorAll('a, button, div[role="button"]'));
  for (const node of nodes) {
    if (!isVisible(node)) {
      continue;
    }

    const label = (node.innerText || node.textContent || node.getAttribute('aria-label') || '').toLowerCase().trim();
    if (label === 'continue to chat' || label === 'use whatsapp web' || label === 'open chat'
        || label === 'use here' || label === 'use on this computer' || label === 'use on this device'
        || label === 'use on this browser' || label === 'switch here') {
      node.click();
      return true;
    }
  }

  return false;
}

function pressEnter(element) {
  element.focus();
  ['keydown', 'keypress', 'keyup'].forEach(type => {
    element.dispatchEvent(new KeyboardEvent(type, {
      bubbles: true,
      cancelable: true,
      key: 'Enter',
      code: 'Enter',
      keyCode: 13,
      which: 13
    }));
  });
}

function isVisible(element) {
  if (!element) {
    return false;
  }
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function normalizeComposerText(text) {
  return String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
}

function normalizePhone(phone) {
  let digits = String(phone || '').replace(/[^\d]/g, '');
  if (!digits) return '';

  // Strip international dialling prefix 00
  if (digits.slice(0, 2) === '00') digits = digits.slice(2);

  // 03XXXXXXXXX (11 digits)
  if (digits.length === 11 && digits.slice(0, 2) === '03') {
    digits = '92' + digits.slice(1);
  // 3XXXXXXXXX (10 digits)
  } else if (digits.length === 10 && digits[0] === '3') {
    digits = '92' + digits;
  // 923XXXXXXXXX (12 digits) — already in target form
  } else if (digits.length === 12 && digits.slice(0, 3) === '923') {
    // keep as-is
  } else {
    // Try stripping a leading 0 once more
    if (digits[0] === '0') digits = digits.slice(1);
    if (digits.length === 10 && digits[0] === '3') {
      digits = '92' + digits;
    } else {
      return ''; // not a recognisable Pakistani mobile
    }
  }

  // Final validation: must be exactly 923XXXXXXXXX (12 digits)
  return (digits.length === 12 && digits.slice(0, 3) === '923') ? digits : '';
}

function getUrlPhone() {
  try {
    return normalizePhone(new URL(window.location.href).searchParams.get('phone') || '');
  } catch (error) {
    return '';
  }
}

function isLoginScreen() {
  const body = document.body ? document.body.innerText.toLowerCase() : '';
  const loginPhrases = [
    'log into whatsapp web',
    'use whatsapp on your computer',
    'to use whatsapp on your computer',
    'scan with whatsapp',
    'link a device',
    'keep your phone connected',
    'whatsapp web requires an active',
    'open whatsapp on your phone'
  ];
  return loginPhrases.some(function(phrase) { return body.indexOf(phrase) !== -1; });
}

function isOfficialWhatsappAccountScreen() {
  const body = document.body ? document.body.innerText.toLowerCase() : '';
  return body.indexOf('only whatsapp can send messages') !== -1
    || (body.indexOf('whatsapp business') !== -1 && body.indexOf('official whatsapp account') !== -1);
}

function findText(text) {
  const body = document.body ? document.body.innerText.toLowerCase() : '';
  return body.indexOf(text) !== -1;
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
