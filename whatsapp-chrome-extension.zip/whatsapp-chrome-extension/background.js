let isRunning = false;
let autoSyncTimerId = null;
let autoSyncInProgress = false;
const AUTO_SYNC_ALARM = 'smart-schools-whatsapp-auto-sync';
const AUTO_SYNC_INTERVAL_MS = 20000;
const AUTO_SYNC_WAKEUP_MINUTES = 0.5;

const DEFAULTS = {
  baseUrl: '',
  securityKey: '',
  batchLimit: 50,
  delayMin: 8,
  delayMax: 15,
  autoSync: true,
  autoSyncPaused: false,
  queue: [],
  sent: 0,
  failed: 0,
  lastSyncAt: '',
  lastSyncMessage: '',
  lastSyncError: '',
  lastSendError: ''
};

chrome.runtime.onInstalled.addListener(() => {
  ensureWorkerId();
  setupAutoSyncAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  setupAutoSyncAlarm();
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === AUTO_SYNC_ALARM) {
    autoSyncTick();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then(data => sendResponse({ok: true, data: data || {}}))
    .catch(error => sendResponse({ok: false, error: error.message || String(error)}));
  return true;
});

async function handleMessage(message) {
  switch (message.type) {
    case 'getSettings':
      return getSettings();
    case 'saveSettings':
      return saveSettings(message.settings || {});
    case 'validate':
      return validateConnection();
    case 'pullCsv':
      return pullCsv();
    case 'importCsvText':
      return importCsvText(message.csv || '');
    case 'start':
      await storageSet({autoSyncPaused: false, lastSyncError: ''});
      await setupAutoSyncAlarm();
      return startSending();
    case 'stop':
      isRunning = false;
      await storageSet({autoSyncPaused: true});
      await setupAutoSyncAlarm();
      return {message: 'Sending stopped.'};
    case 'clearQueue':
      await storageSet({queue: []});
      return {};
    case 'stats':
      return getStats();
    default:
      throw new Error('Unknown extension action.');
  }
}

async function getSettings() {
  const data = await storageGet(Object.keys(DEFAULTS).concat(['workerId']));
  return Object.assign({}, DEFAULTS, data, {workerId: data.workerId || await ensureWorkerId()});
}

async function saveSettings(settings) {
  const existing = await getSettings();
  const delayMin = Math.max(2, Number(settings.delayMin || existing.delayMin || DEFAULTS.delayMin));
  const delayMax = Math.max(delayMin, Number(settings.delayMax || existing.delayMax || DEFAULTS.delayMax));
  const batchLimit = Math.min(200, Math.max(1, Number(settings.batchLimit || existing.batchLimit || DEFAULTS.batchLimit)));

  const next = {
    baseUrl: normalizeBaseUrl(settings.baseUrl || existing.baseUrl || ''),
    securityKey: settings.securityKey || existing.securityKey || '',
    batchLimit: batchLimit,
    delayMin: delayMin,
    delayMax: delayMax,
    autoSync: settings.autoSync === undefined ? existing.autoSync !== false : settings.autoSync !== false,
    autoSyncPaused: false,
    lastSyncError: '',
    workerId: existing.workerId || await ensureWorkerId()
  };

  await storageSet(next);
  await setupAutoSyncAlarm(next);
  return next;
}

async function validateConnection() {
  const settings = await requireSettings();
  const response = await fetch(apiUrl(settings, 'whatsappweb/validatekey', {
    security_key: settings.securityKey
  }));
  const payload = await response.json();
  if (!response.ok || !payload.status) {
    throw new Error(payload.message || 'Invalid Smart Schools WhatsApp security key.');
  }
  return payload;
}

async function pullCsv() {
  const settings = await requireSettings();
  const response = await fetch(apiUrl(settings, 'whatsappweb/pullcsv', {
    security_key: settings.securityKey,
    worker_id: settings.workerId,
    limit: settings.batchLimit
  }));

  if (!response.ok) {
    const errorMessage = 'CSV feed request failed with HTTP ' + response.status + '.';
    await markSyncResult(errorMessage, true);
    throw new Error(errorMessage);
  }

  const csv = await response.text();
  const result = await importCsvText(csv);
  await markSyncResult('Imported ' + result.imported + ' row(s) from dashboard.', false);
  return result;
}

async function importCsvText(csv) {
  const rows = parseCsv(csv);
  const items = csvRowsToItems(rows);
  const imported = await appendQueue(items);
  await storageSet({lastSyncAt: new Date().toISOString()});
  return {imported: imported};
}

async function startSending() {
  if (isRunning) {
    return {message: 'Sending is already running.'};
  }

  isRunning = true;
  processQueue()
    .catch(error => console.error('Smart Schools WhatsApp sender stopped.', error))
    .finally(() => {
      isRunning = false;
    });
  return {message: 'Sending started. Keep WhatsApp Web open and logged in.'};
}

async function processQueue() {
  let pullFailures = 0;
  const MAX_PULL_FAILURES = 3;

  while (isRunning) {
    let queue = await getQueue();
    if (!queue.length) {
      try {
        await pullCsv();
        pullFailures = 0;
      } catch (error) {
        pullFailures++;
        const msg = error.message || String(error);
        await markSyncResult(msg, true);
        console.warn('Smart Schools WhatsApp pull failed (' + pullFailures + '/' + MAX_PULL_FAILURES + '):', msg);
        if (pullFailures >= MAX_PULL_FAILURES) {
          isRunning = false;
          break;
        }
        await delay(5000);
        continue;
      }
      queue = await getQueue();
      if (!queue.length) {
        isRunning = false;
        break;
      }
    }

    const item = queue.shift();
    await storageSet({queue: queue});

    try {
      const result = await sendViaWhatsapp(item);
      await reportItem(item, 'sent', '', JSON.stringify(result || {}));
      await incrementCounter('sent');
      await storageSet({lastSendError: ''});
    } catch (error) {
      const errorMessage = error.message || String(error);
      const globalFailure = isGlobalSendFailure(errorMessage);
      const retryable = !globalFailure && isRetryableSendFailure(errorMessage);
      await reportItem(item, (globalFailure || retryable) ? 'pending' : 'failed', errorMessage, '');
      await storageSet({lastSendError: errorMessage});

      if (globalFailure) {
        await pauseAutoSendingAfterError(errorMessage);
        break;
      }

      if (!retryable) {
        await incrementCounter('failed');
      }
    }

    const settings = await getSettings();
    await delay(randomDelay(settings.delayMin, settings.delayMax));
  }
}

async function pauseAutoSendingAfterError(errorMessage) {
  isRunning = false;
  await storageSet({
    autoSyncPaused: true,
    lastSyncError: errorMessage
  });
  await setupAutoSyncAlarm();
  console.warn('Smart Schools WhatsApp sender paused after a global browser/connectivity error.', errorMessage);
}

function isGlobalSendFailure(errorMessage) {
  const message = String(errorMessage || '').toLowerCase();
  return message.indexOf('whatsapp web is not logged in') !== -1
    || message.indexOf('whatsapp web did not accept the send command') !== -1
    || message.indexOf('whatsapp content script failed') !== -1
    || message.indexOf('receiving end does not exist') !== -1
    || message.indexOf('could not establish connection') !== -1
    || message.indexOf('extension context invalidated') !== -1
    || message.indexOf('message port closed') !== -1
    || message.indexOf('context invalidated') !== -1;
}

function isRetryableSendFailure(errorMessage) {
  const message = String(errorMessage || '').toLowerCase();
  // Composer didn't clear = WhatsApp was slow or tab lost focus; retry rather than fail permanently
  return message.indexOf('did not accept the send command') !== -1
    || message.indexOf('will retry') !== -1;
}

function isWrongChatFailure(errorMessage) {
  const message = String(errorMessage || '').toLowerCase();
  return message.indexOf('official whatsapp business account') !== -1
    || message.indexOf('different phone number than expected') !== -1
    || message.indexOf('did not open the target chat') !== -1;
}

async function sendViaWhatsapp(item) {
  const phone = normalizePhone(item.phone_number || item.phone || '');
  const message = item.message_text || item.message || '';
  if (!phone) {
    throw new Error('Missing phone number.');
  }
  if (!message) {
    throw new Error('Missing message text.');
  }

  const tab = await getOrCreateWhatsappTab();
  const normalizedItem = Object.assign({}, item, {
    phone_number: phone,
    message_text: message
  });

  return sendViaWhatsappWithNavigation(tab, normalizedItem, phone, message);
}

async function sendViaWhatsappWithNavigation(tab, item, phone, message) {
  const sendUrl = buildWhatsappSendUrl(phone, message);

  for (let attempt = 1; attempt <= 2; attempt++) {
    await tabsUpdate(tab.id, {url: 'about:blank', active: true});
    await waitForTabLoad(tab.id, 15000);
    await delay(500);

    await tabsUpdate(tab.id, {url: sendUrl, active: true});
    await waitForTabLoad(tab.id, 60000, sendUrl);
    await delay(attempt === 1 ? 1000 : 2000);

    try {
      return await messageContentScript(tab.id, {
        type: 'SS_SEND_WHATSAPP',
        item: item
      }, 75000);
    } catch (error) {
      if (attempt === 2 || !isWrongChatFailure(error.message || String(error))) {
        throw error;
      }

      await tabsUpdate(tab.id, {url: 'https://web.whatsapp.com/', active: true});
      await waitForTabLoad(tab.id, 30000);
      await delay(3000);
    }
  }
}

function buildWhatsappSendUrl(phone, message) {
  const url = new URL('https://web.whatsapp.com/send');
  url.searchParams.set('phone', phone);
  url.searchParams.set('text', message);
  url.searchParams.set('type', 'phone_number');
  url.searchParams.set('app_absent', '0');
  return url.toString();
}

async function reportItem(item, status, errorMessage, deliveryResponse) {
  if (!item.item_id) {
    return;
  }

  const settings = await requireSettings();
  const body = new URLSearchParams();
  body.set('security_key', settings.securityKey);
  body.set('worker_id', settings.workerId);
  body.set('item_id', item.item_id);
  body.set('status', status);
  body.set('error_message', errorMessage || '');
  body.set('delivery_response', deliveryResponse || '');

  try {
    await fetch(apiUrl(settings, 'whatsappweb/report'), {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
      body: body.toString()
    });
  } catch (error) {
    console.warn('Unable to report WhatsApp item result.', error);
  }
}

async function getOrCreateWhatsappTab() {
  const tabs = await tabsQuery({url: 'https://web.whatsapp.com/*'});
  if (tabs.length) {
    return tabs[0];
  }
  return tabsCreate({url: 'https://web.whatsapp.com/', active: true});
}

function waitForTabLoad(tabId, timeoutMs, expectedUrl) {
  return new Promise(resolve => {
    let done = false;
    const timer = setTimeout(finish, timeoutMs);

    function finish() {
      if (done) {
        return;
      }
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }

    function finishIfReady(tab) {
      if (!expectedUrl || tabMatchesExpectedUrl(tab, expectedUrl)) {
        finish();
      }
    }

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === 'complete') {
        chrome.tabs.get(tabId, tab => {
          if (!chrome.runtime.lastError && tab) {
            finishIfReady(tab);
          }
        });
      }
    }

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId, tab => {
      if (!chrome.runtime.lastError && tab && tab.status === 'complete') {
        finishIfReady(tab);
      }
    });
  });
}

function tabMatchesExpectedUrl(tab, expectedUrl) {
  if (!tab || !tab.url) {
    return false;
  }

  try {
    const current = new URL(tab.url);
    const expected = new URL(expectedUrl);

    // WhatsApp Web is a SPA. After the initial load the URL may change as React
    // processes the route (e.g. params stripped, hash added). Requiring an exact
    // phone-param match caused 60-second stall-outs when the URL mutated.
    // It is enough to confirm the page is on the correct origin; the content
    // script verifies the chat state independently.
    if (current.hostname.endsWith('whatsapp.com') && expected.hostname.endsWith('whatsapp.com')) {
      return true;
    }

    return current.origin === expected.origin
      && current.pathname.replace(/\/+$/, '') === expected.pathname.replace(/\/+$/, '')
      && current.searchParams.get('phone') === expected.searchParams.get('phone');
  } catch (error) {
    return false;
  }
}

async function messageContentScript(tabId, payload, timeoutMs) {
  const started = Date.now();
  let injected = false;
  let lastError = null;

  while (Date.now() - started < timeoutMs) {
    try {
      return await tabsSendMessage(tabId, payload);
    } catch (error) {
      lastError = error;
      if (!isContentScriptConnectionFailure(error.message || String(error))) {
        throw error;
      }

      if (!injected) {
        injected = true;
        try {
          await scriptingExecute({target: {tabId: tabId}, files: ['content.js']});
        } catch (ignored) {
          console.warn(ignored);
        }
      }
      await delay(1000);
    }
  }

  throw new Error(lastError ? lastError.message : 'WhatsApp Web did not accept the send command.');
}

function isContentScriptConnectionFailure(errorMessage) {
  const message = String(errorMessage || '').toLowerCase();
  return message.indexOf('receiving end does not exist') !== -1
    || message.indexOf('could not establish connection') !== -1
    || message.indexOf('extension context invalidated') !== -1
    || message.indexOf('message port closed') !== -1
    || message.indexOf('context invalidated') !== -1;
}

async function setupAutoSyncAlarm(settings) {
  const current = settings || await getSettings();
  if (current.autoSync === false || current.autoSyncPaused === true || !current.baseUrl || !current.securityKey) {
    clearAutoSyncTimer();
    await alarmsClear(AUTO_SYNC_ALARM);
    return;
  }

  await alarmsCreate(AUTO_SYNC_ALARM, {periodInMinutes: AUTO_SYNC_WAKEUP_MINUTES});
  scheduleAutoSyncTimer(1000);
}

async function autoSyncTick() {
  if (autoSyncInProgress) {
    return;
  }

  autoSyncInProgress = true;
  let keepPolling = false;

  try {
    const settings = await getSettings();
    keepPolling = canAutoSync(settings);

    if (!keepPolling) {
      clearAutoSyncTimer();
      await alarmsClear(AUTO_SYNC_ALARM);
      return;
    }

    if (!isRunning) {
      await pullCsv();
      const queue = await getQueue();
      if (queue.length) {
        await startSending();
      }
    }
  } catch (error) {
    await markSyncResult(error.message || String(error), true);
    console.warn('Smart Schools WhatsApp auto sync failed.', error);
  } finally {
    autoSyncInProgress = false;
    if (keepPolling) {
      scheduleAutoSyncTimer();
    }
  }
}

function canAutoSync(settings) {
  return settings.autoSync !== false && settings.autoSyncPaused !== true && !!settings.baseUrl && !!settings.securityKey;
}

function scheduleAutoSyncTimer(delayMs) {
  clearAutoSyncTimer();
  autoSyncTimerId = setTimeout(() => {
    autoSyncTimerId = null;
    autoSyncTick();
  }, delayMs || AUTO_SYNC_INTERVAL_MS);
}

function clearAutoSyncTimer() {
  if (autoSyncTimerId !== null) {
    clearTimeout(autoSyncTimerId);
    autoSyncTimerId = null;
  }
}

async function appendQueue(items) {
  if (!items.length) {
    return 0;
  }

  const queue = await getQueue();
  const seen = {};
  queue.forEach(item => {
    seen[queueKey(item)] = true;
  });

  let imported = 0;
  items.forEach(item => {
    const key = queueKey(item);
    if (!seen[key]) {
      queue.push(item);
      seen[key] = true;
      imported++;
    }
  });

  await storageSet({queue: queue});
  return imported;
}

function csvRowsToItems(rows) {
  if (!rows.length) {
    return [];
  }

  const headers = rows.shift().map(header => String(header).trim().toLowerCase());
  return rows.map(row => {
    const item = {};
    headers.forEach((header, index) => {
      item[header] = row[index] || '';
    });
    return item;
  }).filter(item => (item.phone_number || item.phone) && (item.message_text || item.message));
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;

  for (let index = 0; index < text.length; index++) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"' && inQuotes && next === '"') {
      field += '"';
      index++;
      continue;
    }

    if (char === '"') {
      inQuotes = !inQuotes;
      continue;
    }

    if (char === ',' && !inQuotes) {
      row.push(field);
      field = '';
      continue;
    }

    if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && next === '\n') {
        index++;
      }
      row.push(field);
      if (row.some(value => value !== '')) {
        rows.push(row);
      }
      row = [];
      field = '';
      continue;
    }

    field += char;
  }

  row.push(field);
  if (row.some(value => value !== '')) {
    rows.push(row);
  }

  return rows;
}

async function getQueue() {
  const data = await storageGet(['queue']);
  return Array.isArray(data.queue) ? data.queue : [];
}

async function getStats() {
  const data = await storageGet(['queue', 'sent', 'failed', 'autoSyncPaused', 'lastSyncAt', 'lastSyncMessage', 'lastSyncError', 'lastSendError']);
  return {
    queued: Array.isArray(data.queue) ? data.queue.length : 0,
    sent: Number(data.sent || 0),
    failed: Number(data.failed || 0),
    running: isRunning,
    autoSyncPaused: data.autoSyncPaused === true,
    lastSyncAt: data.lastSyncAt || '',
    lastSyncMessage: data.lastSyncMessage || '',
    lastSyncError: data.lastSyncError || '',
    lastSendError: data.lastSendError || ''
  };
}

async function incrementCounter(key) {
  const data = await storageGet([key]);
  const next = {};
  next[key] = Number(data[key] || 0) + 1;
  await storageSet(next);
}

async function markSyncResult(message, isError) {
  await storageSet({
    lastSyncAt: new Date().toISOString(),
    lastSyncMessage: isError ? '' : (message || ''),
    lastSyncError: isError ? (message || '') : ''
  });
}

async function requireSettings() {
  const settings = await getSettings();
  if (!settings.baseUrl) {
    throw new Error('Smart Schools URL is required.');
  }
  if (!settings.securityKey) {
    throw new Error('Security key is required.');
  }
  return settings;
}

async function ensureWorkerId() {
  const data = await storageGet(['workerId']);
  if (data.workerId) {
    return data.workerId;
  }
  const workerId = 'smart-schools-extension-' + Date.now() + '-' + Math.random().toString(16).slice(2);
  await storageSet({workerId: workerId});
  return workerId;
}

function apiUrl(settings, path, params) {
  const url = new URL(settings.baseUrl + '/' + path.replace(/^\/+/, ''));
  Object.keys(params || {}).forEach(key => url.searchParams.set(key, params[key]));
  return url.toString();
}

function normalizeBaseUrl(value) {
  return String(value || '').trim().replace(/\/+$/, '');
}

function normalizePhone(phone) {
  let digits = String(phone || '').replace(/[^\d]/g, '');
  if (!digits) return '';

  if (digits.slice(0, 2) === '00') digits = digits.slice(2);

  if (digits.length === 11 && digits.slice(0, 2) === '03') {
    digits = '92' + digits.slice(1);
  } else if (digits.length === 10 && digits[0] === '3') {
    digits = '92' + digits;
  } else if (digits.length === 12 && digits.slice(0, 3) === '923') {
    // already correct
  } else {
    if (digits[0] === '0') digits = digits.slice(1);
    if (digits.length === 10 && digits[0] === '3') {
      digits = '92' + digits;
    } else {
      return '';
    }
  }

  return (digits.length === 12 && digits.slice(0, 3) === '923') ? digits : '';
}

function queueKey(item) {
  return item.item_id ? 'id:' + item.item_id : 'raw:' + normalizePhone(item.phone_number || item.phone) + ':' + (item.message_text || item.message || '');
}

function randomDelay(minSeconds, maxSeconds) {
  const min = Math.max(2, Number(minSeconds || 8));
  const max = Math.max(min, Number(maxSeconds || 15));
  return Math.floor((min + Math.random() * (max - min)) * 1000);
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function storageGet(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}

function storageSet(values) {
  return new Promise(resolve => chrome.storage.local.set(values, resolve));
}

function tabsQuery(query) {
  return new Promise(resolve => chrome.tabs.query(query, resolve));
}

function tabsCreate(options) {
  return new Promise(resolve => chrome.tabs.create(options, resolve));
}

function tabsUpdate(tabId, options) {
  return new Promise(resolve => chrome.tabs.update(tabId, options, resolve));
}

function tabsSendMessage(tabId, payload) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, payload, response => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response || response.ok === false) {
        reject(new Error(response && response.error ? response.error : 'WhatsApp content script failed.'));
        return;
      }
      resolve(response.data || {});
    });
  });
}

function scriptingExecute(details) {
  return new Promise((resolve, reject) => {
    chrome.scripting.executeScript(details, result => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(result);
    });
  });
}

function alarmsCreate(name, info) {
  chrome.alarms.create(name, info);
  return Promise.resolve();
}

function alarmsClear(name) {
  return new Promise(resolve => chrome.alarms.clear(name, resolve));
}
